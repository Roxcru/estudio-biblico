package com.estudiobiblico.estudio_biblico_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstudioBiblicoApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstudioBiblicoApiApplication.class, args);
	}

}
